var config = {
    canvas_width: 1280,
    canvas_height: 720,
    canvas_id: "game_area",
    background_color: 0x000000,
    debug_mode: false,
    gravity_value: 680
};

PP.game.create(config);
